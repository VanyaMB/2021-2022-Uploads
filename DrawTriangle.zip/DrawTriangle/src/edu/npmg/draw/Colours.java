package edu.npmg.draw;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Line2D;
import java.awt.geom.Rectangle2D;
import java.awt.geom.Rectangle2D.Double;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;


import javax.swing.JComponent;

public class Colours extends JComponent{
	
	private Color pcolor = Color.RED;
	//private int curx=-10;
	//private int cury=-10;
	private int[] points = new int[7];
	private int index =0;
	private Color pcolors[] = new Color[7];
	private boolean firstClick = true;
	
	private int index2 =0;
	
	public Color getPcolor() {
		return pcolor;
	}
	public void setPcolor(Color pcolor) {
		this.pcolor = pcolor;
	}
	public Colours() {
		super();
		
		addMouseListener(new MouseListener() {

			@Override
			public void mouseClicked(MouseEvent e) {
				
				int curx = e.getX();
				int cury = e.getY();
				//if(index<points.length-1) {
				if(curx>100) {
					points[index] = curx;
					points[index+1] = cury;
					index+=2;
				}
				
				
				
				if(curx>=0 && curx<100) {
					if(cury<100) {
						setPcolor(Color.BLACK);	
					}
					else if(cury>100 && cury<200) {
						setPcolor(Color.WHITE);
					}
					else if(cury>200 && cury<300) {
						setPcolor(Color.RED);
					}
					else if(cury>300 && cury<400) {
						setPcolor(Color.BLUE);
					}
					else {
						setPcolor(Color.GREEN);
					}
					if(!firstClick) {
						pcolors[index2] = getPcolor();
						pcolors[index2+1] = getPcolor();
						index2+=2;
					}
					else {
						pcolors[index2] = Color.RED;
						pcolors[index2+1] = Color.RED;
						index2+=2;
					}
				}
				else {
					repaint();
				}
				if(firstClick) {
					firstClick = false;
					
				}
			}

			@Override
			public void mousePressed(MouseEvent e) {
				// TODO Auto-generated method stub
				
			}

			@Override
			public void mouseReleased(MouseEvent e) {
				// TODO Auto-generated method stub
				
			}

			@Override
			public void mouseEntered(MouseEvent e) {
				// TODO Auto-generated method stub
				
			}

			@Override
			public void mouseExited(MouseEvent e) {
				// TODO Auto-generated method stub
				
			}
			
		});
		
	}
	public void paint(Graphics g) {
		super.paint(g);
		Graphics2D g2d = (Graphics2D) g;
		g2d.setColor(Color.WHITE);
		g2d.fill(new Rectangle2D.Double(getBounds().getX(), getBounds().getY(), getBounds().getWidth(), getHeight()));
		g2d.setColor(Color.BLACK);
		Rectangle2D rect = new Rectangle2D.Double(0, 0, 100, 100);
		g2d.draw(rect);
		g2d.fill(rect);
		g2d.setColor(Color.WHITE);
		rect = new Rectangle2D.Double(0, 100, 100, 100);
		g2d.draw(rect);
		g2d.fill(rect);
		g2d.setColor(Color.RED);
		rect = new Rectangle2D.Double(0, 200, 100, 100);
		g2d.draw(rect);
		g2d.fill(rect);
		g2d.setColor(Color.BLUE);
		rect = new Rectangle2D.Double(0, 300, 100, 100);
		g2d.draw(rect);
		g2d.fill(rect);
		g2d.setColor(Color.GREEN);
		rect = new Rectangle2D.Double(0, 400, 100, 100);
		g2d.draw(rect);
		g2d.fill(rect);
		g2d.setColor(Color.BLACK);
		rect = new Rectangle2D.Double(100, 0, 700, 500);
		g2d.draw(rect);
		if(index>0) {
			for(int i = 0; i < index; i+=2) {
				//if(index<pcolors.length)
				g2d.setColor(pcolors[i]);
				Ellipse2D el = new Ellipse2D.Double(points[i]-5, points[i+1]-5, 10, 10);
				g2d.draw(el);
				g2d.fill(el);
			}
			if(index==6) {
				g2d.setColor(Color.BLACK);
				Line2D line1 = new Line2D.Double(points[0], points[1], points[2], points[3]);
				Line2D line2 = new Line2D.Double(points[0], points[1], points[4], points[5]);
				Line2D line3 = new Line2D.Double(points[2], points[3], points[4], points[5]);
				g2d.draw(line1);
				g2d.draw(line2);
				g2d.draw(line3);
			}
		}
		
		
	}

}
