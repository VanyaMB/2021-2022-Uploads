package edu.npmg.draw;

import java.awt.Color;

import javax.swing.JFrame;

public class Test {

	public static void main(String[] args) {
		
		JFrame window = new JFrame("Draw");
		window.setBounds(0, 0, 900, 900);
		window.setVisible(true);
		window.setLayout(null);
		window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		window.setBackground(Color.WHITE);
		//window.setColor
		Colours c = new Colours();
		c.setBounds(0, 0, 800, 501);
		window.add(c);

	}

}
